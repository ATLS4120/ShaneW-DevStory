//
//  shane_dav_storyApp.swift
//  shane-dav-story
//
//  Created by Shane Wierl on 9/16/24.
//

import SwiftUI

@main
struct shane_dav_storyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
